// This file is deprecated and has been replaced by the new modular structure
// in the /server directory. It can be safely deleted.
