// WARNING: Do not commit this file to version control.
// It is intended for local development only.
// For production, use environment variables.

// Replace "YOUR_E2B_API_KEY_HERE" with your actual E2B API key.
export const E2B_API_KEY: string = "e2b_2607c8a03a6130b14d6f9502ea44b3750c75c14e";